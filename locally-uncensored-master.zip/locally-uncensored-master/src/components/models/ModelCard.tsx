import { Trash2, Info, MessageSquare, Image, Video } from 'lucide-react'
import { formatBytes } from '../../lib/formatters'
import { BenchmarkButton } from './ModelBenchmark'
import type { AIModel } from '../../types/models'

interface Props {
  model: AIModel
  isActive: boolean
  onSelect: () => void
  onDelete: () => void
  onInfo: () => void
  canDelete?: boolean
}

const TYPE_CONFIG = {
  text: { label: 'Text', icon: MessageSquare, color: 'text-blue-400' },
  image: { label: 'Image', icon: Image, color: 'text-purple-400' },
  video: { label: 'Video', icon: Video, color: 'text-green-400' },
}

export function ModelCard({ model, isActive, onSelect, onDelete, onInfo, canDelete = true }: Props) {
  const typeInfo = TYPE_CONFIG[model.type] || TYPE_CONFIG.text
  const TypeIcon = typeInfo.icon

  return (
    <div
      onClick={onSelect}
      className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg border cursor-pointer transition-all group ${
        isActive
          ? 'bg-blue-50 dark:bg-white/[0.05] border-blue-400/40 ring-1 ring-blue-400/40'
          : 'bg-gray-50 dark:bg-white/[0.03] border-gray-200 dark:border-white/[0.06] hover:bg-gray-100 dark:hover:bg-white/[0.05]'
      }`}
    >
      {/* Type icon */}
      <TypeIcon size={13} className={`${typeInfo.color} shrink-0`} />

      {/* Name — grows to fill the row (single-line, LM-Studio style) */}
      <span className="flex-1 min-w-0 text-[0.7rem] text-gray-800 dark:text-gray-200 font-medium truncate">{model.name}</span>

      {isActive && <span className="shrink-0 text-[0.5rem] text-blue-400 font-medium uppercase">Active</span>}

      {/* Compact meta — size · params · quant, dot-separated, mono figures */}
      <span className="hidden md:flex items-center gap-1.5 shrink-0 text-[0.58rem] text-gray-500 lu-hud-num">
        {model.size > 0 && <span>{formatBytes(model.size)}</span>}
        {model.type === 'text' && 'details' in model && model.details?.parameter_size && (
          <><span className="opacity-40">·</span><span>{model.details.parameter_size}</span></>
        )}
        {model.type === 'text' && 'details' in model && model.details?.quantization_level && (
          <><span className="opacity-40">·</span><span>{model.details.quantization_level}</span></>
        )}
        {(model.type === 'image' || model.type === 'video') && (
          <><span className="opacity-40">·</span><span>{model.format || 'safetensors'}</span></>
        )}
      </span>

      {/* Actions — always visible (LM-Studio: no hover-to-reveal) */}
      <div className="flex items-center gap-0.5 shrink-0">
        {model.type === 'text' && (
          <div onClick={(e) => e.stopPropagation()}>
            <BenchmarkButton modelName={model.name} />
          </div>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onInfo() }}
          className="p-1 rounded hover:bg-gray-100 dark:hover:bg-white/10 text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
          title="Details"
        >
          <Info size={12} />
        </button>
        {canDelete && (
          <button
            onClick={(e) => { e.stopPropagation(); onDelete() }}
            className="p-1 rounded hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-colors"
            title="Delete"
          >
            <Trash2 size={12} />
          </button>
        )}
      </div>
    </div>
  )
}
