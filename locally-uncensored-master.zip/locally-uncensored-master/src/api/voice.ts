import { backendCall, isTauri } from "./backend";
import { cloudFetch, jsonOrError, CloudJobError } from "./cloud/client";

/**
 * Voice API.
 * Local mode: STT = local Whisper (faster-whisper) via /local-api/transcribe,
 * TTS = Piper / external engine / browser SpeechSynthesis.
 * Cloud mode (appMode 'cloud'): STT = Whisper large-v3-turbo, TTS = MiniMax
 * Speech-02 — both via the metered lu-labs.ai endpoints (useVoice picks).
 */

let whisperChecked = false
let whisperAvailable = false

export function isSpeechRecognitionSupported(): boolean {
  return whisperAvailable
}

// Call once at startup to check if Whisper is actually running
export async function initWhisperCheck(): Promise<boolean> {
  if (whisperChecked) return whisperAvailable
  try {
    const result = await checkWhisperAvailable()
    whisperAvailable = result.available
  } catch {
    whisperAvailable = false
  }
  whisperChecked = true
  return whisperAvailable
}

// Force a fresh availability probe, bypassing the one-shot cache. Used after
// the in-app faster-whisper install finishes, and when the mic button mounts
// while STT shows unavailable — the persistent Whisper server can take a while
// to load its model after boot, so the first startup probe may have been early.
export async function recheckWhisperAvailable(): Promise<boolean> {
  whisperChecked = false
  return initWhisperCheck()
}

export function isSpeechSynthesisSupported(): boolean {
  return !!window.speechSynthesis;
}

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (!isSpeechSynthesisSupported()) return [];

  let voices = window.speechSynthesis.getVoices();

  if (voices.length === 0) {
    // Voices may load asynchronously; trigger the load
    window.speechSynthesis.onvoiceschanged = () => {};
    voices = window.speechSynthesis.getVoices();
  }

  return voices;
}

export function getVoicesAsync(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (!isSpeechSynthesisSupported()) {
      resolve([]);
      return;
    }

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(voices);
      return;
    }

    window.speechSynthesis.onvoiceschanged = () => {
      resolve(window.speechSynthesis.getVoices());
    };

    // Fallback timeout in case onvoiceschanged never fires
    setTimeout(() => {
      resolve(window.speechSynthesis.getVoices());
    }, 1000);
  });
}

export function speak(
  text: string,
  voice?: SpeechSynthesisVoice,
  rate: number = 1.0,
  pitch: number = 1.0
): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!isSpeechSynthesisSupported()) {
      reject(new Error("Speech synthesis not supported"));
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    if (voice) utterance.voice = voice;
    utterance.rate = rate;
    utterance.pitch = pitch;

    utterance.onend = () => resolve();
    utterance.onerror = (event) => {
      if (event.error === "canceled" || event.error === "interrupted") {
        resolve();
      } else {
        reject(new Error(`Speech synthesis error: ${event.error}`));
      }
    };

    window.speechSynthesis.speak(utterance);
  });
}

/**
 * Speak `text` via the browser SpeechSynthesis fallback.
 *
 * Speaks the whole text as ONE utterance. It used to split into per-sentence
 * utterances and chain them, which hit the well-known Chromium/WebView2 bug
 * where speak() issued right after cancel() silently no-ops — so onend for the
 * 2nd sentence never fired and playback died after the FIRST sentence (#77c,
 * ElBiggus: only "What do you call a fake noodle?" was read, never the punch
 * line). One utterance removes the chaining entirely; stopSpeaking() (cancel)
 * still interrupts instantly. A periodic resume() counters Chromium pausing the
 * synthesizer after ~15 s on a long answer.
 */
export async function speakStreaming(
  text: string,
  voice?: SpeechSynthesisVoice,
  rate?: number,
  pitch?: number
): Promise<void> {
  if (!isSpeechSynthesisSupported()) return;
  stopSpeaking();

  const synth = window.speechSynthesis;
  const trimmed = text.trim();
  if (!trimmed || !synth) return;

  await new Promise<void>((resolve, reject) => {
    const utterance = new SpeechSynthesisUtterance(trimmed);
    if (voice) utterance.voice = voice;
    if (rate !== undefined) utterance.rate = rate;
    if (pitch !== undefined) utterance.pitch = pitch;

    const keepAlive = setInterval(() => {
      try { synth.resume(); } catch { /* engine gone — onend/onerror will settle */ }
    }, 10000);
    let settled = false;
    const cleanup = () => { if (settled) return; settled = true; clearInterval(keepAlive); };

    utterance.onend = () => { cleanup(); resolve(); };
    utterance.onerror = (event) => {
      cleanup();
      if (event.error === "canceled" || event.error === "interrupted") {
        resolve();
      } else {
        reject(new Error(`Speech synthesis error: ${event.error}`));
      }
    };

    synth.speak(utterance);
  });
}

export function stopSpeaking(): void {
  if (isSpeechSynthesisSupported()) {
    window.speechSynthesis.cancel();
  }
}

// --- Local Whisper STT ---

export async function checkWhisperAvailable(): Promise<{
  available: boolean;
  backend: string | null;
  loading?: boolean;
  error?: string;
}> {
  try {
    if (isTauri()) {
      return await backendCall("whisper_status");
    }
    const res = await fetch("/local-api/transcribe-status");
    return res.json();
  } catch {
    return { available: false, backend: null, error: "Failed to reach transcribe-status endpoint" };
  }
}

export async function transcribeAudio(audioBlob: Blob): Promise<string> {
  if (isTauri()) {
    // Convert blob to base64 for Tauri invoke
    const buffer = await audioBlob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const audioBase64 = btoa(binary);
    // Tauri maps the Rust snake_case params (audio_base64, content_type) to
    // camelCase invoke keys — passing snake_case silently fails the command
    // ("missing required key audioBase64") → every transcription returned
    // nothing. THIS was the "mic records but no text" bug.
    const data = await backendCall("transcribe", {
      audioBase64,
      contentType: audioBlob.type || "audio/wav",
    });
    if (data.error) throw new Error(data.error);
    return data.transcript || "";
  }

  const res = await fetch("/local-api/transcribe", {
    method: "POST",
    headers: { "Content-Type": audioBlob.type || "audio/webm" },
    body: audioBlob,
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.transcript || "";
}

// --- LU Cloud voice (appMode 'cloud') ---

/** Cloud STT: POST the recorded clip to /api/voice/transcribe (Whisper
 *  large-v3-turbo, flat-metered per request — so useVoice disables the
 *  interim-streaming cadence in cloud mode and only sends the final take). */
export async function transcribeAudioCloud(audioBlob: Blob): Promise<string> {
  const res = await cloudFetch("/api/voice/transcribe", {
    method: "POST",
    headers: { "content-type": audioBlob.type || "audio/wav" },
    body: audioBlob,
  });
  const data = await jsonOrError<{ text?: string }>(res);
  return data.text || "";
}

// The cloud TTS route rejects text over 1500 chars (zod BodySchema) — a
// typical assistant answer is longer. Split into ≤1400-char pieces on sentence
// boundaries (hard-splitting any single oversized run) so long messages read
// aloud instead of 400ing and silently degrading to the local/browser voice.
const TTS_MAX_CHARS = 1400;
export function chunkForTts(text: string, max = TTS_MAX_CHARS): string[] {
  const clean = text.trim();
  if (clean.length <= max) return clean ? [clean] : [];
  const parts = clean.split(/(?<=[.!?。！？\n])\s+/);
  const chunks: string[] = [];
  let cur = "";
  for (const p of parts) {
    if (p.length > max) {
      if (cur) { chunks.push(cur); cur = ""; }
      for (let i = 0; i < p.length; i += max) chunks.push(p.slice(i, i + max));
      continue;
    }
    if ((cur ? cur.length + 1 + p.length : p.length) > max) {
      if (cur) chunks.push(cur);
      cur = p;
    } else {
      cur = cur ? `${cur} ${p}` : p;
    }
  }
  if (cur) chunks.push(cur);
  return chunks;
}

/** Cloud TTS: /api/voice/tts streams back MP3 (MiniMax Speech-02). Returns an
 *  object URL for playNeuralAudio (which revokes it when the clip settles).
 *  `signal` aborts the in-flight synthesis — the server cancels un-metered. */
export async function synthesizeCloud(text: string, voice?: string, signal?: AbortSignal): Promise<string> {
  const res = await cloudFetch("/api/voice/tts", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ text, ...(voice ? { voice } : {}) }),
    signal,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}) as { error?: string });
    throw new CloudJobError(
      typeof body.error === "string" ? body.error : `cloud TTS failed (${res.status})`,
      res.status,
    );
  }
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

// --- Local neural TTS (Piper) ---
// Synthesizes via the bundled Piper voice through the Rust `synthesize` command
// (100% local, no cloud). The browser SpeechSynthesis path in useVoice handles
// the case where neural TTS isn't installed.

let ttsChecked = false;
let ttsAvailableFlag = false;

export async function checkTtsAvailable(): Promise<{ available: boolean; piper?: boolean; voice?: boolean }> {
  try {
    if (isTauri()) return await backendCall("tts_status");
    return { available: false };
  } catch {
    return { available: false };
  }
}

export async function initTtsCheck(): Promise<boolean> {
  if (ttsChecked) return ttsAvailableFlag;
  try {
    ttsAvailableFlag = (await checkTtsAvailable()).available;
  } catch {
    ttsAvailableFlag = false;
  }
  ttsChecked = true;
  return ttsAvailableFlag;
}

// Force a fresh probe (after the in-app install, or when a Speaker button mounts
// while neural TTS still shows unavailable).
export async function recheckTtsAvailable(): Promise<boolean> {
  ttsChecked = false;
  return initTtsCheck();
}

/** Synthesize text to a playable WAV data URL via a local Piper voice. */
export async function synthesizeNeural(text: string, voice?: string): Promise<string> {
  const data = await backendCall<{ audio_base64?: string; mime?: string }>("synthesize", { text, voice });
  if (!data?.audio_base64) throw new Error("neural TTS returned no audio");
  return `data:${data.mime || "audio/wav"};base64,${data.audio_base64}`;
}

/**
 * Synthesize text via a user-configured external HTTP TTS engine (GitHub #58).
 * `url` is an OpenAI-compatible endpoint (e.g. Kokoro-FastAPI at
 * http://localhost:8880/v1/audio/speech); `voice` is that engine's voice name.
 * Returns a playable data URL (the Rust side honors the returned audio type).
 */
export async function synthesizeExternal(text: string, url: string, voice?: string): Promise<string> {
  const data = await backendCall<{ audio_base64?: string; mime?: string }>("synthesize_external", { text, url, voice });
  if (!data?.audio_base64) throw new Error("external TTS returned no audio");
  return `data:${data.mime || "audio/wav"};base64,${data.audio_base64}`;
}

/** Download a Piper voice model on demand. Blocks until done (~63 MB). */
export async function downloadPiperVoice(voice: string): Promise<void> {
  await backendCall("download_voice", { voice });
}

/** Voice ids already present on disk — used to mark the Settings picker. */
export async function listInstalledPiperVoices(): Promise<string[]> {
  try {
    if (isTauri()) return (await backendCall<string[]>("installed_piper_voices")) || [];
    return [];
  } catch {
    return [];
  }
}

let neuralAudio: HTMLAudioElement | null = null;
let neuralAudioDone: (() => void) | null = null;

/** Play a WAV data URL or MP3 blob URL; resolves when playback ends (or is
 *  stopped via stopNeuralAudio). Replaces any current clip. Object URLs are
 *  revoked once the clip settles so cloud TTS blobs don't pin memory. */
export function playNeuralAudio(dataUrl: string): Promise<void> {
  return new Promise((resolve, reject) => {
    stopNeuralAudio();
    const audio = new Audio(dataUrl);
    const cleanup = () => {
      if (neuralAudio === audio) { neuralAudio = null; neuralAudioDone = null; }
      if (dataUrl.startsWith("blob:")) URL.revokeObjectURL(dataUrl);
    };
    neuralAudio = audio;
    neuralAudioDone = () => { cleanup(); resolve(); };
    audio.onended = () => { cleanup(); resolve(); };
    audio.onerror = () => {
      cleanup();
      reject(new Error("neural audio playback failed"));
    };
    audio.play().catch((err) => { cleanup(); reject(err); });
  });
}

export function stopNeuralAudio(): void {
  if (neuralAudio) {
    try { neuralAudio.pause(); } catch { /* noop */ }
    // pause() never fires onended — settle the pending playNeuralAudio promise
    // explicitly (which also revokes a blob: URL) so callers' awaits don't
    // dangle forever after a Stop click.
    const done = neuralAudioDone;
    neuralAudio = null;
    neuralAudioDone = null;
    done?.();
  }
}

// --- Audio Recorder (Web Audio PCM → 16 kHz mono WAV) ---
//
// We deliberately do NOT use MediaRecorder here. MediaRecorder with a timeslice
// emits *fragmented* webm/opus chunks; concatenating them yields a blob whose
// header/cues are incomplete, which faster-whisper (PyAV/ffmpeg) often fails to
// decode → empty transcript (the "mic on but no text" bug). Capturing raw PCM
// via Web Audio and encoding a clean 16 kHz mono WAV is what faster-whisper
// expects natively, and it lets us take mid-recording WAV snapshots for live
// streaming transcription.

export interface AudioRecorder {
  start: () => Promise<void>;
  /** Final 16 kHz mono WAV of the whole take. */
  stop: () => Promise<Blob>;
  /** 16 kHz mono WAV of everything captured so far (for streaming interim STT). */
  snapshot: () => Blob | null;
  isRecording: () => boolean;
}

const STT_TARGET_RATE = 16000;

function floatTo16BitPCM(samples: Float32Array): Int16Array {
  const out = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

// Box-filter downsample to the target rate (Whisper wants 16 kHz). Averaging
// the source window is a cheap anti-alias that beats naive decimation.
function downsampleTo(input: Float32Array, inRate: number, outRate: number): Float32Array {
  if (outRate >= inRate || input.length === 0) return input;
  const ratio = inRate / outRate;
  const outLen = Math.floor(input.length / ratio);
  const out = new Float32Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const start = Math.floor(i * ratio);
    const end = Math.min(input.length, Math.floor((i + 1) * ratio));
    let sum = 0, n = 0;
    for (let j = start; j < end; j++) { sum += input[j]; n++; }
    out[i] = n ? sum / n : input[start] || 0;
  }
  return out;
}

function encodeWav(samples: Int16Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);
  const writeStr = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  writeStr(0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true); // PCM fmt chunk size
  view.setUint16(20, 1, true); // format = PCM
  view.setUint16(22, 1, true); // channels = mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true); // byte rate (mono, 16-bit)
  view.setUint16(32, 2, true); // block align
  view.setUint16(34, 16, true); // bits per sample
  writeStr(36, "data");
  view.setUint32(40, samples.length * 2, true);
  let off = 44;
  for (let i = 0; i < samples.length; i++, off += 2) view.setInt16(off, samples[i], true);
  return new Blob([view], { type: "audio/wav" });
}

export function createAudioRecorder(): AudioRecorder {
  let audioCtx: AudioContext | null = null;
  let source: MediaStreamAudioSourceNode | null = null;
  let processor: ScriptProcessorNode | null = null;
  let mute: GainNode | null = null;
  let stream: MediaStream | null = null;
  let pcmChunks: Float32Array[] = [];
  let inputRate = 48000;
  let recording = false;

  const buildWav = (): Blob | null => {
    if (!pcmChunks.length) return null;
    let total = 0;
    for (const c of pcmChunks) total += c.length;
    if (total === 0) return null;
    const merged = new Float32Array(total);
    let o = 0;
    for (const c of pcmChunks) { merged.set(c, o); o += c.length; }
    const ds = downsampleTo(merged, inputRate, STT_TARGET_RATE);
    return encodeWav(floatTo16BitPCM(ds), STT_TARGET_RATE);
  };

  return {
    start: async () => {
      pcmChunks = [];
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtx = new Ctx();
      inputRate = audioCtx.sampleRate;
      source = audioCtx.createMediaStreamSource(stream);
      // ScriptProcessor is deprecated but works reliably in WebView2 without the
      // AudioWorklet module-loading dance. 4096-frame buffer ≈ 85 ms at 48 kHz.
      processor = audioCtx.createScriptProcessor(4096, 1, 1);
      processor.onaudioprocess = (e) => {
        if (!recording) return;
        // Copy — the underlying buffer is reused by the audio thread.
        pcmChunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
      };
      // Route through a zero-gain node so onaudioprocess fires WITHOUT echoing
      // the mic to the speakers.
      mute = audioCtx.createGain();
      mute.gain.value = 0;
      source.connect(processor);
      processor.connect(mute);
      mute.connect(audioCtx.destination);
      // getUserMedia is awaited just above, which can drop the user-gesture
      // activation → the AudioContext may start "suspended" and never fire
      // onaudioprocess (= silent capture, empty WAV). Resume explicitly.
      if (audioCtx.state === "suspended") {
        try { await audioCtx.resume(); } catch { /* noop */ }
      }
      recording = true;
    },

    stop: () => {
      return new Promise<Blob>((resolve) => {
        recording = false;
        const wav = buildWav() || new Blob([], { type: "audio/wav" });
        try { processor?.disconnect(); } catch { /* noop */ }
        try { source?.disconnect(); } catch { /* noop */ }
        try { mute?.disconnect(); } catch { /* noop */ }
        try { stream?.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
        try { void audioCtx?.close(); } catch { /* noop */ }
        processor = null; source = null; mute = null; audioCtx = null; stream = null;
        resolve(wav);
      });
    },

    snapshot: () => buildWav(),

    isRecording: () => recording,
  };
}
