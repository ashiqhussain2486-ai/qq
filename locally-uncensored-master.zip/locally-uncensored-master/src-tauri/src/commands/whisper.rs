use std::io::{BufRead, BufReader, Write};
use std::process::{Child, Command, Stdio};
use std::sync::{mpsc, Arc, Mutex};
use std::path::PathBuf;

#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

use base64::Engine;
use tauri::{AppHandle, Manager, State};
use tracing::{error, info};

use crate::state::AppState;

#[cfg(target_os = "windows")]
const CREATE_NO_WINDOW: u32 = 0x08000000;

pub struct WhisperServer {
    process: Option<Child>,
    stdin_tx: Option<std::io::BufWriter<std::process::ChildStdin>>,
    response_rx: Option<mpsc::Receiver<serde_json::Value>>,
    pub ready: bool,
    pub backend: Option<String>,
}

impl WhisperServer {
    pub fn new() -> Self {
        Self {
            process: None,
            stdin_tx: None,
            response_rx: None,
            ready: false,
            backend: None,
        }
    }

    pub fn start(&mut self, python_bin: &str, script_path: &str) -> Result<(), String> {
        if self.process.is_some() {
            return Ok(());
        }

        println!("[Whisper] Starting persistent server: {} {}", python_bin, script_path);

        let mut cmd = Command::new(python_bin);
        cmd.arg(script_path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        #[cfg(target_os = "windows")]
        cmd.creation_flags(CREATE_NO_WINDOW);
        let mut child = cmd.spawn()
            .map_err(|e| format!("Failed to start whisper server: {}", e))?;

        let stdin = child.stdin.take().ok_or("Failed to get stdin")?;
        let stdout = child.stdout.take().ok_or("Failed to get stdout")?;
        let stderr = child.stderr.take().ok_or("Failed to get stderr")?;

        self.stdin_tx = Some(std::io::BufWriter::new(stdin));

        // Channel for passing responses from reader thread to callers
        let (tx, rx) = mpsc::channel();
        self.response_rx = Some(rx);

        // Stdout reader thread — parses JSON lines from whisper_server.py
        let tx_clone = tx.clone();
        std::thread::spawn(move || {
            let reader = BufReader::new(stdout);
            for line in reader.lines() {
                if let Ok(line) = line {
                    let trimmed = line.trim();
                    if trimmed.is_empty() {
                        continue;
                    }
                    if let Ok(json) = serde_json::from_str::<serde_json::Value>(trimmed) {
                        let _ = tx_clone.send(json);
                    }
                }
            }
        });

        // Stderr reader thread — log Python output
        std::thread::spawn(move || {
            let reader = BufReader::new(stderr);
            for line in reader.lines() {
                if let Ok(line) = line {
                    if !line.trim().is_empty() {
                        println!("[Whisper] {}", line.trim());
                    }
                }
            }
        });

        self.process = Some(child);

        // Wait for the "ready" signal (up to 5 minutes for model loading)
        if let Some(ref rx) = self.response_rx {
            match rx.recv_timeout(std::time::Duration::from_secs(300)) {
                Ok(msg) => {
                    if msg.get("status").and_then(|s| s.as_str()) == Some("ready") {
                        self.ready = true;
                        self.backend = msg.get("backend").and_then(|b| b.as_str()).map(|s| s.to_string());
                        println!("[Whisper] Server ready (backend: {})", self.backend.as_deref().unwrap_or("unknown"));
                    } else if msg.get("status").and_then(|s| s.as_str()) == Some("error") {
                        let err = msg.get("error").and_then(|e| e.as_str()).unwrap_or("unknown");
                        return Err(format!("Whisper server error: {}", err));
                    }
                }
                Err(_) => {
                    return Err("Whisper server did not become ready within 5 minutes".to_string());
                }
            }
        }

        Ok(())
    }

    pub fn send_command(&mut self, cmd: &serde_json::Value) -> Result<serde_json::Value, String> {
        if !self.ready {
            return Err("Whisper server not ready".to_string());
        }

        let stdin = self.stdin_tx.as_mut().ok_or("No stdin connection")?;
        let json_str = serde_json::to_string(cmd).map_err(|e| e.to_string())?;

        stdin.write_all(json_str.as_bytes()).map_err(|e| format!("stdin write: {}", e))?;
        stdin.write_all(b"\n").map_err(|e| format!("stdin newline: {}", e))?;
        stdin.flush().map_err(|e| format!("stdin flush: {}", e))?;

        // Wait for response (60s timeout for transcription)
        let rx = self.response_rx.as_ref().ok_or("No response channel")?;
        rx.recv_timeout(std::time::Duration::from_secs(60))
            .map_err(|_| "Whisper transcription timed out".to_string())
    }

    /// Whether the whisper server child is currently running (model resident).
    pub fn is_running(&self) -> bool {
        self.process.is_some()
    }

    pub fn stop(&mut self) {
        if let Some(ref mut stdin) = self.stdin_tx {
            let _ = stdin.write_all(b"{\"action\":\"quit\"}\n");
            let _ = stdin.flush();
        }
        if let Some(ref mut child) = self.process {
            let _ = child.kill();
        }
        self.process = None;
        self.stdin_tx = None;
        self.response_rx = None;
        self.ready = false;
        println!("[Whisper] Server stopped");
    }
}

#[tauri::command]
pub fn whisper_status(state: State<'_, AppState>) -> Result<serde_json::Value, String> {
    let (running, ready, backend) = {
        let whisper = state.whisper.lock().unwrap();
        (whisper.process.is_some(), whisper.ready, whisper.backend.clone())
    };
    // Report INSTALLED-on-disk, not merely "server process running". The whisper
    // server lazy-starts on first mic use and is killed on quit, so keying the
    // badge on process.is_some() made STT read as uninstalled after every
    // relaunch — the "reinstall every launch" report (#78, ElBiggus). If the
    // server is up it's obviously installed; otherwise probe the resolved
    // interpreter for the faster_whisper package.
    let available = running || whisper_package_installed(state.inner());
    Ok(serde_json::json!({
        "available": available,
        "backend": backend,
        "loading": running && !ready,
    }))
}

/// Is `faster_whisper` importable in the interpreter install_whisper targets
/// (resolve_lu_python: ComfyUI venv if present, else system Python)? Cheap
/// best-effort probe so the badge reflects a prior install across relaunches
/// without the server running. Any spawn/timeout failure → "not installed".
fn whisper_package_installed(state: &AppState) -> bool {
    let python = crate::commands::install::resolve_lu_python(state);
    if python.is_empty() {
        return false;
    }
    let mut cmd = Command::new(&python);
    // Probe INSTALLABILITY with importlib.find_spec, NOT a full
    // `import faster_whisper`. The real import pulls in ctranslate2 / onnxruntime
    // / av and takes ~8 s warm (longer with a cold OS file cache), which on the
    // first status check right after a cold relaunch blew past the cap below and
    // made STT read as "not installed" until the next check — the #78 symptom,
    // softened but not gone. find_spec answers "is the package present" in about
    // 100 ms with no heavy import, so the badge is right on the very first probe.
    cmd.args([
        "-c",
        "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('faster_whisper') else 1)",
    ])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    let mut child = match cmd.spawn() {
        Ok(c) => c,
        Err(_) => return false,
    };
    // find_spec returns in well under a second; the cap is kept purely so a
    // wedged interpreter can never hang the status call.
    for _ in 0..100 {
        match child.try_wait() {
            Ok(Some(status)) => return status.success(),
            Ok(None) => std::thread::sleep(std::time::Duration::from_millis(100)),
            Err(_) => return false,
        }
    }
    let _ = child.kill();
    false
}

#[tauri::command]
pub fn transcribe(app: AppHandle, audio_base64: String, content_type: String, state: State<'_, AppState>) -> Result<serde_json::Value, String> {
    let audio_bytes = base64::engine::general_purpose::STANDARD
        .decode(&audio_base64)
        .map_err(|e| format!("base64 decode: {}", e))?;

    if audio_bytes.is_empty() {
        return Err("Empty audio data".to_string());
    }

    // Determine file extension
    let ext = if content_type.contains("wav") { ".wav" }
        else if content_type.contains("mp3") || content_type.contains("mpeg") { ".mp3" }
        else if content_type.contains("ogg") { ".ogg" }
        else if content_type.contains("mp4") || content_type.contains("m4a") { ".m4a" }
        else { ".webm" };

    // Write to temp file
    let tmp_dir = std::env::temp_dir();
    let tmp_file = tmp_dir.join(format!("whisper-{}{}", std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0), ext));

    std::fs::write(&tmp_file, &audio_bytes)
        .map_err(|e| format!("Write temp file: {}", e))?;

    let audio_path = tmp_file.to_string_lossy().replace('\\', "/");
    println!("[Whisper] Transcribing: {} ({:.1} KB)", audio_path, audio_bytes.len() as f64 / 1024.0);

    // Lazy-start Whisper on first use — it is no longer pre-started at launch
    // (it kept ~360 MB resident even in Cloud mode). Block until the server is
    // spawned; send_command below then waits for the model to finish loading.
    {
        let needs_start = state.whisper.lock().map(|w| w.process.is_none()).unwrap_or(true);
        if needs_start {
            // Resolve the SAME interpreter install_whisper used (ComfyUI venv if
            // present, else system Python). Using state.python_bin here meant a
            // venv install was invisible at runtime → STT silently dead after
            // relaunch on boxes with a ComfyUI venv (#78).
            let python_bin = crate::commands::install::resolve_lu_python(state.inner());
            if python_bin.is_empty() {
                return Err("Whisper unavailable: no Python runtime detected. Install Python in the setup step, then retry.".to_string());
            }
            auto_start_whisper_sync(&app, &python_bin, &state.whisper);
        }
    }

    // Send to persistent whisper server
    let result = {
        let mut whisper = state.whisper.lock().unwrap();
        whisper.send_command(&serde_json::json!({
            "action": "transcribe",
            "path": audio_path,
        }))
    };

    // Clean up temp file
    let _ = std::fs::remove_file(&tmp_file);

    match result {
        Ok(response) => {
            if let Some(transcript) = response.get("transcript").and_then(|t| t.as_str()) {
                println!("[Whisper] Transcribed: \"{}\" (lang: {})",
                    transcript.chars().take(80).collect::<String>(),
                    response.get("language").and_then(|l| l.as_str()).unwrap_or("?"));
                info!("transcribe ok");
            }
            Ok(response)
        }
        Err(e) => {
            error!(error = %e, "transcribe failed");
            Err(e)
        }
    }
}

/// Synchronous whisper startup (runs in background thread)
pub fn auto_start_whisper_sync(app: &tauri::AppHandle, python_bin: &str, whisper: &Arc<Mutex<WhisperServer>>) {
    // Check if faster-whisper is installed
    let mut cmd = Command::new(python_bin);
    cmd.args(["-c", "import faster_whisper"]);
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    let check = cmd.output();

    match check {
        Ok(output) if output.status.success() => {
            println!("[Whisper] faster-whisper found, starting persistent server...");
        }
        _ => {
            println!("[Whisper] faster-whisper not installed — STT disabled");
            return;
        }
    }

    // Resolve whisper_server.py path from bundled resources
    let script_path: Option<PathBuf> = app.path()
        .resource_dir()
        .ok()
        .map(|d: PathBuf| d.join("resources").join("whisper_server.py"))
        .filter(|p: &PathBuf| p.exists())
        .or_else(|| {
            let dev_path = PathBuf::from("public").join("whisper_server.py");
            if dev_path.exists() { Some(dev_path) } else { None }
        });

    match script_path {
        Some(path) => {
            let path_str: String = path.to_string_lossy().to_string();
            let mut ws = whisper.lock().unwrap();
            if let Err(e) = ws.start(python_bin, &path_str) {
                println!("[Whisper] Failed to start: {}", e);
            }
        }
        None => {
            println!("[Whisper] whisper_server.py not found");
        }
    }
}
